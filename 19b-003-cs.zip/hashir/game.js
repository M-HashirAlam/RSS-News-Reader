$(document).ready(function () {
     
        var url = 'http://feeds.feedburner.com/daily-express-gaming';
        $.ajax({  
            type: 'GET',  
            url: "https://api.rss2json.com/v1/api.json?rss_url=" + url,
            dataType: 'jsonp',
    
            success: function(data) {  
              console.log(data)
                alert('Success');  
                $("#rss-default").append(data.feed);  
                console.log(data.feed.description);  
            },
            Error: function (data) {
                       let errorMsg = `<div class="errorMsg center">Some error occured</div>`;
                      $("#rss-default").html(errorMsg);
            }
                
        });  
      });